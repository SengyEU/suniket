import { Outlet, useLocation } from "react-router-dom";
import { useEffect } from "react";
import Nav from "./Nav.jsx";
import Footer from "./Footer.jsx";

function Layout() {
    const location = useLocation();

    useEffect(() => {
        const titles = {
            "/": "Domů",
            "/about": "O kapele",
            "/concerts": "Koncerty",
            "/gallery": "Galerie",
        };
        const pageTitle = titles[location.pathname] || "";
        document.title = `Suniket | ${pageTitle}`;
    }, [location.pathname]);

    return (
        <div className="w-full min-h-screen bg-black text-white flex flex-col">
            <Nav />
            <main>
                <Outlet />
            </main>
            <Footer />
        </div>
    );
}

export default Layout;
