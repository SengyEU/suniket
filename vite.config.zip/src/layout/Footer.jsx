function Footer() {
    return (
        <footer style={{ padding: "1rem", background: "#222", color: "#fff", marginTop: "2rem", textAlign: "center" }}>
            &copy; 2025 Moje Kapela |{" "}
            <a href="mailto:kontakt@kapela.cz" style={{ color: "#fff" }}>
                kontakt@kapela.cz
            </a>
        </footer>
    );
}

export default Footer;
