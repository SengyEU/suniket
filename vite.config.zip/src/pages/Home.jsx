import { useEffect } from "react";

export default function Home() {
    useEffect(() => {
        document.title = "Kapela | Domů";
    }, []);

    return <></>;
}
