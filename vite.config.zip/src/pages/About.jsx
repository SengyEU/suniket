function About() {
    return (
        <>
            <h1>O kapele</h1>
            <p>Trochu informací o historii a členech kapely.</p>
        </>
    );
}

export default About;
